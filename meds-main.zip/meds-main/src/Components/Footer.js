import React from 'react';
import "../Components/css/Footer.css"

const Footer = () => {
	return(
		<div className='footer'>
		Footer
		</div>
		);
};

export default Footer;