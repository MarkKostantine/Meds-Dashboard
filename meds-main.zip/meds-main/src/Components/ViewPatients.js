import React from 'react';
// import "./css/Medsdetails.css"

const ViewPatients = () => {
	return (
	<div className='Medsdetails p-5'>
		<div className='row'>
			<div className='col-4'>
				<img className='product-image' src='https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460__340.png' alt=""/>
			</div>
			<div className ='col-8'>
				<h3>Ptient 1 </h3>
				<p> stomach ache patient </p>
			</div>
		</div>
	</div>
		)
}

export default ViewPatients;